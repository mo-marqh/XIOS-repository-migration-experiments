# Acknowledgement for non-FCM Work

Licences for non-FCM works included in this distribution can be
found in the licences/ directory.

Non-FCM works included in this distribution are listed below:

doc/etc/bootstrap/:
* Unmodified external software library copyright 2011-2015 Twitter, Inc
  released under the MIT license.
  See [Bootstrap](http://getbootstrap.com/).

svn-hooks/svnperms.py:
* Subversion repository pre-commit path-based permission checking utility,
  written by [Gustavo Niemeyer](mailto:gustavo@niemeyer.net) and released under
  Apache 2.0 license.
  Original source downloaded from r1295006 at:
  https://svn.apache.org/viewvc/subversion/trunk/tools/hook-scripts/svnperms.py
  This version is modified to allow custom permission message per repository.
