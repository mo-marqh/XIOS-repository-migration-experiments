#include <stdio.h>

void hello_c_ () {
  printf ("%s\n", "Hello_C: Hello Earth!");
}
