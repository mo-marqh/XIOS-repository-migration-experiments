#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""The Python, by Hilaire Belloc

A Python I should not advise,--
It needs a doctor for its eyes,
And has the measles yearly.
However, if you feel inclined
To get one (to improve your mind,
And not from fashion merely),
Allow no music near its cage;
And when it flies into a rage
Chastise it, most severely.
I had an aunt in Yucatan
Who bought a Python from a man
And kept it for a pet.
She died, because she never knew
These simple little rules and few;--
The Snake is living yet.
"""

import this

print "\n",  __doc__
