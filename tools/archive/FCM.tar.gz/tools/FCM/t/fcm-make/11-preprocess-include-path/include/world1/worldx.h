character(*), parameter :: world1 = 'Earth'
