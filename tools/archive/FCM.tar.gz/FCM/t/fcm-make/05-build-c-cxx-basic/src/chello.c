#include <stdio.h>

int main() {
    printf("Hello C\n");
    return 0;
}
