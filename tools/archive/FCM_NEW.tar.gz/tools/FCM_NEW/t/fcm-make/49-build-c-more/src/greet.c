#include <stdio.h>
void main(void) {
    printf("Greet World\n");
}
